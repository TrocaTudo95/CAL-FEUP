var searchData=
[
  ['defineedgecolor',['defineEdgeColor',['../class_graph_viewer.html#a4102580b69826ba83251ef7bb262f8be',1,'GraphViewer']]],
  ['defineedgecurved',['defineEdgeCurved',['../class_graph_viewer.html#a08f362be0e682d91e7506dca8caae1b8',1,'GraphViewer']]],
  ['defineedgedashed',['defineEdgeDashed',['../class_graph_viewer.html#af785279b5c204df0e274b20c36276fc3',1,'GraphViewer']]],
  ['definevertexcolor',['defineVertexColor',['../class_graph_viewer.html#a76de8676b7a93d72af514b84cdaa4d21',1,'GraphViewer']]],
  ['definevertexicon',['defineVertexIcon',['../class_graph_viewer.html#af1adb6a361457187a820e01dcf0a34b7',1,'GraphViewer']]],
  ['definevertexsize',['defineVertexSize',['../class_graph_viewer.html#ac4b2a9fec74d38e64088aa79ca4b7d9b',1,'GraphViewer']]],
  ['dijkstrabesttime',['dijkstraBestTime',['../class_graph.html#a19c3559dc86f0dd1da72a157f864f449',1,'Graph']]],
  ['dijkstrabesttimewithfavoritetransport',['dijkstraBestTimeWithFavoriteTransport',['../class_graph.html#a7bc7e3e61b1a753e8e043cf3e713cdc4',1,'Graph']]],
  ['dijkstrabesttimewithwaitingtime',['dijkstraBestTimeWithWaitingTime',['../class_graph.html#ae1ed9f85f6201ed1b4f095cf4533eb9c',1,'Graph']]],
  ['dijkstralesstransportsused',['dijkstraLessTransportsUsed',['../class_graph.html#a747e004c927e230f380d58a399ce9e72',1,'Graph']]],
  ['dijkstrashortestdistance',['dijkstraShortestDistance',['../class_graph.html#ab8c22a8531c0fccd1e7e555ece7b388d',1,'Graph::dijkstraShortestDistance(const int &amp;s)'],['../class_graph.html#aa7ed404a514a3c1bbbd7b9404b715b85',1,'Graph::dijkstraShortestDistance(const int &amp;s, const int &amp;d)']]]
];
